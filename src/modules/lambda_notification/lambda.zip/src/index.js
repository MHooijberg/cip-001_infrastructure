// ================== EXAMPLE EVENT BODY ==================
// {
//     "firstName": "Julius",
//     "lastName": "Caesar",
//     "email": "emperor@senate.rome",
//     "phoneNumber": "+1 555 123-4567",
//     "company": "Some companie",
//     "role": "strategy",
//     "subject": "some subject",
//     "message": "a long winded message about their impropper security."
// }
import { SESv2Client, SendEmailCommand } from "@aws-sdk/client-sesv2";

const ses = new SESv2Client({ region: process.env.AWS_REGION || "eu-north-1" });
const TO_ADDRESS = process.env.TO_ADDRESS; // your destination email (e.g. you@example.com)
const FROM_ADDRESS = process.env.FROM_ADDRESS; // must be verified in SES

export const handler = async (event) => {
    console.log("Received event:", JSON.stringify(event));
    
    try {
        const body = parseEventBody(event);

        if (!body || Object.keys(body).length === 0) {
            throw new Error("Invalid body");
        }

        for (const [key, val] of Object.entries(body)) {
            if (typeof val === "string" && val.length > 2000) {
                return jsonResponse(400, { error: `${key} too long.` });
            }
        }

        const sanitized = {};
        for (const [key, val] of Object.entries(body)) {
            sanitized[key] = sanitize(val);
        }
        
        const {
            firstName,
            lastName,
            email,
            phone: phoneNumber,
            company,
            role,
            subject,
            message
        } = sanitized;
        
        // Validate minimal required fields
        if (!email || !subject || !message) {
            return jsonResponse(400, { error: "Missing required fields." });
        }
        
        const fullName = `${firstName ?? ""} ${lastName ?? ""}`.trim();
        const htmlBody = generateHtmlBody({ fullName, email, phoneNumber, company, role, subject, message });
        const textBody = generateTextBody({ fullName, email, phoneNumber, company, role, subject, message });
        
        const params = {
            FromEmailAddress: FROM_ADDRESS,
            Destination: { ToAddresses: [TO_ADDRESS] },
            Content: {
                Simple: {
                    Subject: { Data: `Contact Form: ${subject}` },
                    Body: {
                        Text: { Data: textBody },
                        Html: { Data: htmlBody }
                    }
                }
            },
            ReplyToAddresses: [email]
        };
        
        await ses.send(new SendEmailCommand(params));
        
        return jsonResponse(200, { success: true, message: "Email sent successfully." });
    } catch (err) {
        console.error("Error sending email:", err);
        return jsonResponse(500, { error: "Failed to send email." });
    }
};

function sanitize(str) {
    if (typeof str !== "string") return "";
    return str
        .replace(/[&<>"'`=\/]/g, s => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;",
            "`": "&#x60;",
            "=": "&#x3D;",
            "/": "&#x2F;"
        }[s]))
        .trim();
}

function parseEventBody(event) {
    let rawBody = event.body;

    if (!rawBody) return {};

    // If body is base64 encoded (e.g., API Gateway proxy integration)
    if (event.isBase64Encoded) {
        rawBody = Buffer.from(rawBody, "base64").toString("utf8");
    }

    // Assume JSON
    try {
        return typeof rawBody === "string" ? JSON.parse(rawBody) : rawBody;
    } catch {
        console.warn("Could not parse body as JSON, returning raw string.");
        return { rawBody };
    }
}

function jsonResponse(statusCode, body) {
    return {
        statusCode,
        headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Methods": "OPTIONS,POST",
            "Content-Type": "application/json"
        },
        body: JSON.stringify(body)
    };
}

function generateHtmlBody({ fullName, email, phoneNumber, company, role, subject, message }) {
    return `
        <div style="font-family: Arial, sans-serif; color: #333; line-height: 1.5; max-width: 600px; margin: 0 auto; background: #fafafa; border-radius: 8px; padding: 20px;">
        <h2 style="color: #222; border-bottom: 2px solid #4a90e2; padding-bottom: 8px;">New Contact Form Submission</h2>
        
        <table style="width: 100%; border-collapse: collapse; margin-top: 15px;">
            <tr><td style="padding: 4px 0;"><strong>Name:</strong></td><td>${fullName || "N/A"}</td></tr>
            <tr><td style="padding: 4px 0;"><strong>Email:</strong></td><td>${email || "N/A"}</td></tr>
            <tr><td style="padding: 4px 0;"><strong>Phone:</strong></td><td>${phoneNumber || "N/A"}</td></tr>
            <tr><td style="padding: 4px 0;"><strong>Company:</strong></td><td>${company || "N/A"}</td></tr>
            <tr><td style="padding: 4px 0;"><strong>Role:</strong></td><td>${role || "N/A"}</td></tr>
            <tr><td style="padding: 4px 0;"><strong>Subject:</strong></td><td>${subject || "N/A"}</td></tr>
        </table>
        
        <hr style="margin: 20px 0; border: none; border-top: 1px solid #ddd;">
        
        <p style="white-space: pre-wrap;">${message || "N/A"}</p>
        </div>
    `;
}

function generateTextBody({ fullName, email, phoneNumber, company, role, subject, message }) {
    return `
New Contact Form Submission
----------------------------
    
Name: ${fullName|| "N/A"}
Email: ${email || "N/A"}
Phone: ${phoneNumber || "N/A"}
Company: ${company || "N/A"}
Role: ${role || "N/A"}
Subject: ${subject} || "N/A"
    
Message:
    ${message || "N/A"}
  `.trim();
}
